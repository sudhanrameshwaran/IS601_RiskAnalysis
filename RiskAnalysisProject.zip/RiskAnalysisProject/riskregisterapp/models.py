from django.db import models

class RiskList(models.Model):
    riskid = models.CharField(max_length=64)
    name = models.CharField(max_length=64)
    desc = models.CharField(max_length=256)
    priority = models.CharField(
        max_length=1,
        choices=[
            ('1',"High"),
            ('2',"Medium"),
            ('3',"Low")
        ]
    severity = models.CharField(
        max_length=1,
        choices=[
            ('1',"High"),
            ('2',"Medium"),
            ('3',"Low")
        ]
    )
    assignedto = models.CharField(max_length=64)
    identifieddate = models.DateField()
    resolutiondate = models.DateField()
    
    