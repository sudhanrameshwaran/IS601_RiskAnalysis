from django.apps import AppConfig


class RiskregisterappConfig(AppConfig):
    name = 'riskregisterapp'
