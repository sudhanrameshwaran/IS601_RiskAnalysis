from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('riskregister', views.RiskRegister, name='riskregister'),
    path('your-name', views.get_name, name='get_name'),
    path('risklist', views.risklist, name='risklist'),
]